Hello,
You received a message from : {{ $name }}

<p>
    User Name: {{ $name }}
</p>

<p>
    User Email: {{ $email }}
</p>

<p>
    Message provided: {{ $user_message }}
</p>
