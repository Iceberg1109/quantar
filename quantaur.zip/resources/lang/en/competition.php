<?php
return [

    "days" => "{0} today|{1} 1 day ago |[2,*] :days days ago",

];