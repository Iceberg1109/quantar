<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Emailrequest extends Model
{
    protected $fillable = ["email"];
    
}
