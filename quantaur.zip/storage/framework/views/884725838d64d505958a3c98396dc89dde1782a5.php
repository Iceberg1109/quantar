<?php $__env->startSection("componentcss"); ?>
<link href="<?php echo e(asset('front/css/client/mycampaigns.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="content-container">
        <h4 class="title">My campaigns</h4>
        <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row">
                <div class="col-md-12 container-white row blue-border mt-3">
                    <div class="col-xs-12 col-md-2">
                        <h4><?php echo e($record->name); ?></h4>
                    </div>
                    <div class="col-sm-12 col-md-2 flex">
                        <i class="far fa-clock"></i>
                        <p><?php echo e($record->timing); ?></p>
                    </div>
                    <div class="col-sm-12 col-md-2 flex">
                        <i class="far fa-calendar-alt"></i>
                        <p><?php echo e($record->star_date); ?></p>
                    </div>
                    <div class="col-sm-12 col-md-2 flex">
                        <i class="fab fa-react"></i>
                        <p><?php echo e($record->data_type); ?></p>
                    </div>
                    <div class="col-sm-12 col-md-4 flex">
                        <i class="far fa-clipboard"></i>
                        <p><?php echo e($record->topic); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="d-block">
                <h5>Your currently have no campaigns</h5>
            </div>
        <?php endif; ?>
<!--         <h4 class="title">Completed Campaigns</h4>
        <div class="col-md-12 container-white margin-top-20 row">
            <div class="col-sm-12 col-md-2">
                <h4>Campaign 8</h4>
            </div>
            <div class="col-sm-12 col-md-2 flex">
                <i class="far fa-clock"></i>
                <p>6 months</p>
            </div>
            <div class="col-sm-12 col-md-2 flex">
                <i class="far fa-calendar-alt"></i>
                <p>04/06/2019</p>
            </div>
            <div class="col-sm-12 col-md-2 flex">
                <i class="fab fa-react"></i>
                <p>Structured Data/Tubular</p>
            </div>
            <div class="col-sm-12 col-md-4 flex">
                <i class="far fa-clipboard"></i>
                <p>Intelligent Image/Video Search</p>
            </div>
        </div> -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("client.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>