<?php $__env->startSection("componentcss"); ?>
<link href="<?php echo e(asset('front/css/client/details.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="content-container">
        <h4 class="title d-block">Account Details</h4>
        <div class="col-sm-12 col-md-4 row container-white mt-4">
            <div class="col-sm-12 col-md-5">
                <h4 style="color: #ccc">User</h4>
            </div>
            <div class="col-sm-12 col-md-7">
                <h4><?php echo e(auth()->user()->name); ?></h4>
            </div>
        </div>
        <div class="col-md-12 row mt-4 pl-0">
            <div class="container-white row col-sm-12 col-md-4">
                <div class="col-sm-12 col-md-5">
                    <h4 style="color: #ccc">Email</h4>
                </div>
                <div class="col-sm-12 col-md-7">
                    <h4><?php echo e(auth()->user()->email); ?></h4>
                </div>
                <!-- <div class="change-btn-mobile">
                    <a style="">Change</a>
                </div> -->
            </div>
            <!-- <div class="change-btn-full">
                <a>Change</a>
            </div> -->
        </div>
        <div class="col-md-12 row mt-4 pl-0">
            <div class="container-white row col-sm-12 col-md-4">
                <div class="col-sm-12 col-md-5">
                    <h4 style="color: #ccc">Access Code</h4>
                </div>
                <div class="col-sm-12 col-md-7">
                    <h4><?php echo e(auth()->user()->psw); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-2 mt-4 p-0">
            <button type="button" class="btn btn-default btn-block" onclick="document.getElementById('logout-form').submit();">Sign Out</button>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("client.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>